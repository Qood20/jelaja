<?php if (isset($component)) { $__componentOriginal5863877a5171c196453bfa0bd807e410 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal5863877a5171c196453bfa0bd807e410 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.layouts.app','data' => ['title' => 'Kelola Destinasi']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('layouts.app'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['title' => 'Kelola Destinasi']); ?>
    <div class="flex items-center justify-between">
        <h1 class="text-2xl font-semibold">Destinasi Wisata</h1>
        <a href="<?php echo e(route('operator.destinations.create')); ?>" class="rounded bg-blue-700 px-4 py-2 text-white">Tambah</a>
    </div>
    <div class="mt-4 grid grid-cols-1 gap-4 md:grid-cols-3">
        <?php $__currentLoopData = $destinations; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $destination): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="overflow-hidden rounded-xl border bg-white">
                <img src="<?php echo e($destination->image_url ?: 'https://images.unsplash.com/photo-1469474968028-56623f02e42e?q=80&w=1200&auto=format&fit=crop'); ?>" alt="<?php echo e($destination->name); ?>" class="h-40 w-full object-cover">
                <div class="p-4">
                <h3 class="font-semibold"><?php echo e($destination->name); ?></h3>
                <p class="text-sm text-slate-600">Rp<?php echo e(number_format($destination->price, 0, ',', '.')); ?></p>
                <div class="mt-3 flex flex-col gap-2">
                    <a href="<?php echo e(route('operator.destinations.show', $destination)); ?>" class="rounded bg-blue-500 px-3 py-1 text-center text-sm text-white hover:bg-blue-600">Lihat</a>

                    <a href="<?php echo e(route('operator.destinations.edit', $destination)); ?>" class="rounded bg-amber-500 px-3 py-1 text-center text-sm text-white hover:bg-amber-600">Edit</a>
                    <form action="<?php echo e(route('operator.destinations.destroy', $destination)); ?>" method="POST">
                        <?php echo csrf_field(); ?> <?php echo method_field('DELETE'); ?>
                        <button class="w-full rounded bg-red-600 px-3 py-1 text-sm text-white hover:bg-red-700">Hapus</button>
                    </form>
                </div>
                </div>
            </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>
    <div class="mt-4"><?php echo e($destinations->links()); ?></div>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal5863877a5171c196453bfa0bd807e410)): ?>
<?php $attributes = $__attributesOriginal5863877a5171c196453bfa0bd807e410; ?>
<?php unset($__attributesOriginal5863877a5171c196453bfa0bd807e410); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal5863877a5171c196453bfa0bd807e410)): ?>
<?php $component = $__componentOriginal5863877a5171c196453bfa0bd807e410; ?>
<?php unset($__componentOriginal5863877a5171c196453bfa0bd807e410); ?>
<?php endif; ?>
<?php /**PATH D:\laragon\www\jelaja\resources\views/operator/destinations/index.blade.php ENDPATH**/ ?>