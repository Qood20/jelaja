<?php if (isset($component)) { $__componentOriginal5863877a5171c196453bfa0bd807e410 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal5863877a5171c196453bfa0bd807e410 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.layouts.app','data' => ['title' => 'Login - Jelaja']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('layouts.app'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['title' => 'Login - Jelaja']); ?>
    <div class="mx-auto max-w-md rounded-xl border bg-white p-6">
        <h1 class="text-xl font-semibold">Login</h1>
        <form action="<?php echo e(route('login.attempt')); ?>" method="POST" class="mt-4 space-y-4">
            <?php echo csrf_field(); ?>
            <input type="email" name="email" placeholder="Email" class="w-full rounded border px-3 py-2" required>
            <input type="password" name="password" placeholder="Password" class="w-full rounded border px-3 py-2" required>
            <button class="w-full rounded bg-blue-700 px-4 py-2 text-white">Masuk</button>
        </form>
        <div class="mt-4 text-center text-sm text-slate-600">
            Belum punya akun? <a href="<?php echo e(route('register')); ?>" class="font-medium text-blue-700 hover:text-blue-800">Register di sini</a>
        </div>
    </div>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal5863877a5171c196453bfa0bd807e410)): ?>
<?php $attributes = $__attributesOriginal5863877a5171c196453bfa0bd807e410; ?>
<?php unset($__attributesOriginal5863877a5171c196453bfa0bd807e410); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal5863877a5171c196453bfa0bd807e410)): ?>
<?php $component = $__componentOriginal5863877a5171c196453bfa0bd807e410; ?>
<?php unset($__componentOriginal5863877a5171c196453bfa0bd807e410); ?>
<?php endif; ?>
<?php /**PATH D:\laragon\www\jelaja\resources\views/auth/login.blade.php ENDPATH**/ ?>