<?php if (isset($component)) { $__componentOriginal5863877a5171c196453bfa0bd807e410 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal5863877a5171c196453bfa0bd807e410 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.layouts.app','data' => ['title' => 'Detail User']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('layouts.app'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['title' => 'Detail User']); ?>
    <div class="mx-auto max-w-3xl rounded-3xl bg-white p-6 shadow-sm">
        <h1 class="text-2xl font-semibold">Detail User</h1>
        <div class="mt-6 grid gap-4 rounded-3xl border border-slate-200 bg-slate-50 p-6 text-sm text-slate-700 md:grid-cols-2">
            <div>
                <p class="font-semibold text-slate-900">Nama</p>
                <p><?php echo e($user->name); ?></p>
            </div>
            <div>
                <p class="font-semibold text-slate-900">Email</p>
                <p><?php echo e($user->email); ?></p>
            </div>
            <div>
                <p class="font-semibold text-slate-900">Role</p>
                <p><?php echo e(ucfirst($user->role)); ?></p>
            </div>
            <div>
                <p class="font-semibold text-slate-900">Status</p>
                <p><?php echo e(ucfirst($user->status)); ?></p>
            </div>
            <div>
                <p class="font-semibold text-slate-900">Dibuat Pada</p>
                <p><?php echo e($user->created_at->format('d M Y H:i')); ?></p>
            </div>
            <div>
                <p class="font-semibold text-slate-900">Terakhir Diperbarui</p>
                <p><?php echo e($user->updated_at->format('d M Y H:i')); ?></p>
            </div>
        </div>
        <div class="mt-6 flex flex-wrap gap-3">
            <a href="<?php echo e(route('admin.users.edit', $user)); ?>" class="rounded-full bg-blue-700 px-5 py-3 text-sm font-semibold text-white hover:bg-blue-800">Edit User</a>
            <a href="<?php echo e(route('admin.users.index')); ?>" class="rounded-full border border-slate-300 px-5 py-3 text-sm font-medium text-slate-700 hover:bg-slate-100">Kembali</a>
        </div>
    </div>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal5863877a5171c196453bfa0bd807e410)): ?>
<?php $attributes = $__attributesOriginal5863877a5171c196453bfa0bd807e410; ?>
<?php unset($__attributesOriginal5863877a5171c196453bfa0bd807e410); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal5863877a5171c196453bfa0bd807e410)): ?>
<?php $component = $__componentOriginal5863877a5171c196453bfa0bd807e410; ?>
<?php unset($__componentOriginal5863877a5171c196453bfa0bd807e410); ?>
<?php endif; ?>
<?php /**PATH D:\laragon\www\jelaja\resources\views/admin/users/show.blade.php ENDPATH**/ ?>