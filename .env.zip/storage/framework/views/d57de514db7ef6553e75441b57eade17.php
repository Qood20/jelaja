<?php if (isset($component)) { $__componentOriginal5863877a5171c196453bfa0bd807e410 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal5863877a5171c196453bfa0bd807e410 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.layouts.app','data' => ['title' => 'Register - Jelaja']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('layouts.app'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['title' => 'Register - Jelaja']); ?>
    <div class="mx-auto max-w-md rounded-xl border bg-white p-6">
        <h1 class="text-xl font-semibold">Register</h1>
        <form action="<?php echo e(route('register.store')); ?>" method="POST" class="mt-4 space-y-4">
            <?php echo csrf_field(); ?>
            <input type="text" name="name" placeholder="Nama lengkap" class="w-full rounded border px-3 py-2" required>
            <input type="email" name="email" placeholder="Email" class="w-full rounded border px-3 py-2" required>
            <select name="role" class="w-full rounded border px-3 py-2" required>
                <option value="buyer">Pembeli</option>
                <option value="operator">Operator Wisata</option>
            </select>
            <input type="password" name="password" placeholder="Password" class="w-full rounded border px-3 py-2" required>
            <input type="password" name="password_confirmation" placeholder="Konfirmasi Password" class="w-full rounded border px-3 py-2" required>
            <button class="w-full rounded bg-blue-700 px-4 py-2 text-white">Daftar</button>
        </form>
        <div class="mt-4 text-center text-sm text-slate-600">
            Sudah punya akun? <a href="<?php echo e(route('login')); ?>" class="font-medium text-blue-700 hover:text-blue-800">Login di sini</a>
        </div>
    </div>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal5863877a5171c196453bfa0bd807e410)): ?>
<?php $attributes = $__attributesOriginal5863877a5171c196453bfa0bd807e410; ?>
<?php unset($__attributesOriginal5863877a5171c196453bfa0bd807e410); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal5863877a5171c196453bfa0bd807e410)): ?>
<?php $component = $__componentOriginal5863877a5171c196453bfa0bd807e410; ?>
<?php unset($__componentOriginal5863877a5171c196453bfa0bd807e410); ?>
<?php endif; ?>
<?php /**PATH D:\laragon\www\jelaja\resources\views/auth/register.blade.php ENDPATH**/ ?>