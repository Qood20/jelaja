<?php if (isset($component)) { $__componentOriginal5863877a5171c196453bfa0bd807e410 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal5863877a5171c196453bfa0bd807e410 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.layouts.app','data' => ['title' => 'Konfirmasi Pembelian']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('layouts.app'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['title' => 'Konfirmasi Pembelian']); ?>
    <div class="mx-auto max-w-2xl space-y-6">
        <div class="rounded-3xl bg-white p-6 shadow-sm">
            <h1 class="text-2xl font-semibold text-slate-900">Konfirmasi Pembelian</h1>
            <p class="mt-2 text-sm text-slate-600">Pastikan detail pesanan Anda sudah benar sebelum melanjutkan pembayaran.</p>
        </div>

        <div class="rounded-3xl bg-white p-6 shadow-sm">
            <h2 class="text-lg font-semibold text-slate-900"><?php echo e($destination->name); ?></h2>
            <div class="mt-4 space-y-3 text-sm">
                <div class="flex justify-between">
                    <span class="text-slate-600">Tanggal Kunjungan:</span>
                    <span class="font-medium"><?php echo e(\Carbon\Carbon::parse($visit_date)->format('d M Y')); ?></span>
                </div>
                <div class="flex justify-between">
                    <span class="text-slate-600">Jumlah Tiket:</span>
                    <span class="font-medium"><?php echo e($quantity); ?></span>
                </div>
                <div class="flex justify-between">
                    <span class="text-slate-600">Harga per Tiket:</span>
                    <span class="font-medium">Rp<?php echo e(number_format($destination->price, 0, ',', '.')); ?></span>
                </div>
                <hr class="border-slate-200">
                <div class="flex justify-between text-base font-semibold">
                    <span>Total:</span>
                    <span>Rp<?php echo e(number_format($total, 0, ',', '.')); ?></span>
                </div>
            </div>
        </div>

        <div class="rounded-3xl bg-amber-50 p-6 text-sm text-amber-800">
            <p class="font-medium">Informasi Penting:</p>
            <ul class="mt-2 space-y-1">
                <li>• Setelah pembayaran berhasil, tiket QR Code akan muncul di menu "Tiket Saya".</li>
                <li>• Pastikan tanggal kunjungan sesuai dengan jadwal Anda.</li>
                <li>• Pembayaran diproses oleh Midtrans dengan aman.</li>
            </ul>
        </div>

        <form action="<?php echo e(route('buyer.checkout.confirm', $destination)); ?>" method="POST" class="space-y-4">
            <?php echo csrf_field(); ?>
            <input type="hidden" name="visit_date" value="<?php echo e($visit_date); ?>">
            <input type="hidden" name="quantity" value="<?php echo e($quantity); ?>">
            <div class="flex gap-3">
                <a href="<?php echo e(route('buyer.destinations.show', $destination)); ?>" class="flex-1 rounded-xl border border-slate-300 bg-white px-5 py-3 text-center text-sm font-semibold text-slate-700 transition hover:bg-slate-50">Kembali</a>
                <button type="submit" class="flex-1 rounded-xl bg-blue-700 px-5 py-3 text-sm font-semibold text-white transition hover:bg-blue-800">Bayar Sekarang</button>
            </div>
        </form>
    </div>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal5863877a5171c196453bfa0bd807e410)): ?>
<?php $attributes = $__attributesOriginal5863877a5171c196453bfa0bd807e410; ?>
<?php unset($__attributesOriginal5863877a5171c196453bfa0bd807e410); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal5863877a5171c196453bfa0bd807e410)): ?>
<?php $component = $__componentOriginal5863877a5171c196453bfa0bd807e410; ?>
<?php unset($__componentOriginal5863877a5171c196453bfa0bd807e410); ?>
<?php endif; ?><?php /**PATH D:\laragon\www\jelaja\resources\views/buyer/checkout/confirm.blade.php ENDPATH**/ ?>